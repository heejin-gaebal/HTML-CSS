package main;

public class Main {

	public static void main(String[] args) {
		//회원 로그인
		MovieProcess movieProcess = new MovieProcess();
		movieProcess.movieRecommender();
		//영화 등록
		//리뷰
	}

}
